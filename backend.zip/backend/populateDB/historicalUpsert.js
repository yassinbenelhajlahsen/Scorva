/**
 * historicalUpsert.js
 *
 * Fetches daily scores and boxscore data from ESPN’s public APIs, then bulk‐upserts:
 * 1) Teams (home + away) in one multi‐row INSERT … ON CONFLICT
 * 2) Games (including broadcast + quarter‐by‐quarter string scores)
 * 3) Players
 * 4) Stats
 *
 * This version ensures:
 *  • gameID is never null by including `eventid` in the INSERT/CONFLICT target
 *  • Quarter scores are stored as "firstqtr":"30-12", etc.
 *  • Broadcast names are joined by "/" if multiple markets exist
 *  • `statement_timeout` is disabled per‐transaction so large inserts do not error
 */

import dotenv from "dotenv";
import axios from "axios";
import pkg from "pg";
import mapStatsToSchema from "./mapStatsToSchema.js";
import upsertPlayer from "./upsertPlayer.js";
import upsertStat from "./upsertStat.js";
import upsertGame from "./upsertGame.js";
import upsertTeam from "./upsertTeam.js";

dotenv.config();
const { Pool } = pkg;

console.log("🔵 [DEBUG] Initializing database pool...");
const pool = new Pool({
  connectionString: process.env.DB_URL,
  // If you prefer to raise the default timeout for every query, you could also uncomment:
  // statement_timeout: 60000, // 60 seconds
});

pool.on("connect", (client) => {
  console.log("🔵 [DEBUG] New client connected to pool");
});
pool.on("remove", (client) => {
  console.log("🔵 [DEBUG] Client disconnected from pool");
});
pool.on("error", (err) => {
  console.error("🔴 [DEBUG] Pool error:", err);
});

// ----------------------------------------------------------------------------
// 1) upsertGame: now includes `eventid` in both INSERT and ON CONFLICT
// ----------------------------------------------------------------------------

/**
 * Upserts a single game into the `games` table.  
 * Expects the `games` table to have at least these columns:
 *   eventid      INTEGER  UNIQUE (or part of a composite UNIQUE)
 *   league       TEXT
 *   date         DATE
 *   hometeamid   INTEGER
 *   awayteamid   INTEGER
 *   homescore    INTEGER
 *   awayscore    INTEGER
 *   venue        TEXT
 *   broadcast    TEXT
 *   firstqtr     TEXT
 *   secondqtr    TEXT
 *   thirdqtr     TEXT
 *   fourthqtr    TEXT
 *   ot1          TEXT
 *   ot2          TEXT
 *   ot3          TEXT
 *   ot4          TEXT
 *   status       TEXT
 *   season       TEXT
 *
 * Note: We’ve changed the conflict target to `(eventid, league)` so that
 *       `gameID` will always be returned, whether inserted or updated.
 */


// ----------------------------------------------------------------------------
// 2) bulkUpsertTeams: same as before, batched home+away
// ----------------------------------------------------------------------------

/**
 * Bulk-upserts multiple teams in one SQL call.  
 * Must have a UNIQUE constraint on (team_id, league).
 *
 * @param {PoolClient} client
 * @param {string} leagueSlug
 * @param {Array<Object>} teamsArray  
 *        each: { teamId, displayName, shortDisplayName, location, logoUrl, record, homerecord, awayrecord }
 * @returns {Promise<Array<number>>}  // [homeTeamId, awayTeamId]
 */
async function bulkUpsertTeams(client, leagueSlug, teamsArray) {
  if (!teamsArray.length) return [];

  const columns = [
    "team_id",
    "league",
    "display_name",
    "short_display_name",
    "location",
    "logo_url",
    "record",
    "home_record",
    "away_record",
  ];

  const placeholders = [];
  const values = [];
  let idx = 1;

  for (const t of teamsArray) {
    placeholders.push(
      `($${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++}, $${idx++})`
    );
    values.push(
      t.teamId,
      leagueSlug,
      t.displayName,
      t.shortDisplayName,
      t.location,
      t.logoUrl,
      t.record,
      t.homerecord,
      t.awayrecord
    );
  }

  const sql = `
    INSERT INTO teams (${columns.join(", ")})
      VALUES ${placeholders.join(", ")}
    ON CONFLICT (team_id, league) DO UPDATE
      SET
        display_name       = EXCLUDED.display_name,
        short_display_name = EXCLUDED.short_display_name,
        location           = EXCLUDED.location,
        logo_url           = EXCLUDED.logo_url,
        record             = EXCLUDED.record,
        home_record        = EXCLUDED.home_record,
        away_record        = EXCLUDED.away_record
    RETURNING team_id;
  `;

  const res = await client.query(sql, values);
  return res.rows.map((r) => r.team_id);
}

// ----------------------------------------------------------------------------
// 3) Helper to convert period number → key name
// ----------------------------------------------------------------------------

function periodKey(periodNumber) {
  switch (periodNumber) {
    case 1:
      return "firstqtr";
    case 2:
      return "secondqtr";
    case 3:
      return "thirdqtr";
    case 4:
      return "fourthqtr";
    case 5:
      return "ot1";
    case 6:
      return "ot2";
    case 7:
      return "ot3";
    case 8:
      return "ot4";
    default:
      return `period${periodNumber}`;
  }
}

// ----------------------------------------------------------------------------
// 4) fetchPlayerDetails: same as before
// ----------------------------------------------------------------------------

async function fetchPlayerDetails(athleteId, leagueSlug) {
  const athleteUrl = `https://site.web.api.espn.com/apis/common/v3/sports/${getSportPath(
    leagueSlug
  )}/${leagueSlug}/athletes/${athleteId}`;
  console.log(`🔵 [DEBUG] Fetching player details from: ${athleteUrl}`);
  try {
    const response = await axios.get(athleteUrl);
    console.log(`🔵 [DEBUG] Successfully fetched details for athlete ${athleteId}`);
    return response.data;
  } catch (err) {
    console.warn(`⚠️ [DEBUG] Could not fetch details for athlete ${athleteId}: ${err.message}`);
    return null;
  }
}

// ----------------------------------------------------------------------------
// 5) getAllDatesInRange + getSportPath (unchanged)
// ----------------------------------------------------------------------------

function getAllDatesInRange(startISO, endISO) {
  console.log(`🔵 [DEBUG] Generating dates from ${startISO} to ${endISO}`);
  const dates = [];
  const curr = new Date(startISO);
  const last = new Date(endISO);
  while (curr <= last) {
    const yyyy = curr.getUTCFullYear().toString();
    const mm = String(curr.getUTCMonth() + 1).padStart(2, "0");
    const dd = String(curr.getUTCDate()).padStart(2, "0");
    dates.push(`${yyyy}${mm}${dd}`);
    curr.setUTCDate(curr.getUTCDate() + 1);
  }
  console.log(`🔵 [DEBUG] Generated ${dates.length} dates`);
  return dates;
}

function getSportPath(leagueSlug) {
  switch (leagueSlug.toLowerCase()) {
    case "nba":
      return "basketball";
    case "nfl":
      return "football";
    case "nhl":
      return "hockey";
    default:
      throw new Error(`Unsupported league slug: ${leagueSlug}`);
  }
}

// ----------------------------------------------------------------------------
// 6) populateDateForLeague: the main per‐date logic
// ----------------------------------------------------------------------------

async function populateDateForLeague(dateString, leagueSlug) {
  console.log(`\n🔵 [DEBUG] Processing ${leagueSlug} for date ${dateString}`);
  const scoreboardUrl = `https://site.api.espn.com/apis/site/v2/sports/${getSportPath(
    leagueSlug
  )}/${leagueSlug}/scoreboard?dates=${dateString}`;
  console.log(`🔵 [DEBUG] Fetching scoreboard from: ${scoreboardUrl}`);

  let respHist;
  try {
    respHist = await axios.get(scoreboardUrl);
    console.log(`🔵 [DEBUG] Successfully fetched scoreboard for ${dateString}`);
  } catch (err) {
    console.error(`🔴 [DEBUG] Failed to fetch scoreboard for ${dateString}: ${err.message}`);
    return;
  }

  const combinedEvents = respHist.data.events || [];
  console.log(`🔵 [DEBUG] Found ${combinedEvents.length} events for ${dateString}`);

  for (const [eventIdx, event] of combinedEvents.entries()) {
    console.log(
      `\n🔵 [DEBUG] Processing event ${eventIdx + 1}/${combinedEvents.length}: ${event.name}`
    );
    const espnEventId = parseInt(event.id, 10);
    const isoDateOnly = event.date.slice(0, 10);

    const comps = event.competitions[0].competitors;
    const homeComp = comps.find((c) => c.homeAway === "home");
    const awayComp = comps.find((c) => c.homeAway === "away");

    console.log(
      `🔵 [DEBUG] Home team: ${homeComp.team.displayName}, Away team: ${awayComp.team.displayName}`
    );

    const client = await pool.connect();
    console.log(`🔵 [DEBUG] Acquired database client for event ${espnEventId}`);

    try {
      console.log(`🔵 [DEBUG] Starting transaction for event ${espnEventId}`);
      await client.query("BEGIN");

      // ─── Disable statement_timeout for this transaction ───
      await client.query("SET LOCAL statement_timeout = 0");

      // 1) Bulk-upsert home + away teams
      console.log("🔵 [DEBUG] Bulk upserting both teams in one statement");
      const teamsToUpsert = [
        {
          teamId: parseInt(homeComp.team.id, 10),
          displayName: homeComp.team.displayName,
          shortDisplayName: homeComp.team.name,
          location: homeComp.team.location,
          logoUrl: homeComp.team.logo,
          record: homeComp.records?.[0]?.summary || "0-0",
          homerecord: homeComp.records?.find((r) => r.type === "home")?.summary || "0-0",
          awayrecord: homeComp.records?.find((r) => r.type === "road")?.summary || "0-0",
        },
        {
          teamId: parseInt(awayComp.team.id, 10),
          displayName: awayComp.team.displayName,
          shortDisplayName: awayComp.team.name,
          location: awayComp.team.location,
          logoUrl: awayComp.team.logo,
          record: awayComp.records?.[0]?.summary || "0-0",
          homerecord: awayComp.records?.find((r) => r.type === "home")?.summary || "0-0",
          awayrecord: awayComp.records?.find((r) => r.type === "road")?.summary || "0-0",
        },
      ];

      const returnedTeamIds = await bulkUpsertTeams(client, leagueSlug, teamsToUpsert);
      const [homeTeamId, awayTeamId] = returnedTeamIds;
      console.log(`🔵 [DEBUG] Bulk upsert returned IDs: home=${homeTeamId}, away=${awayTeamId}`);

      // 2) Build broadcast string (e.g. ["TNT","Bally Sports"] → "TNT/Bally Sports")
      const rawBroadcast = event.competitions[0].broadcast || [];
      const broadcastNames = rawBroadcast.map((b) => b.name).filter(Boolean);
      const broadcastStr = broadcastNames.length > 0 ? broadcastNames.join("/") : null;

      // 3) Build quarter-by-quarter object
      const linesHome = homeComp.linescores || [];
      const linesAway = awayComp.linescores || [];
      const quartersObj = {};

      for (let idx = 0; idx < linesHome.length; idx++) {
        const homeLine = linesHome[idx];
        const awayLine =
          linesAway[idx] || { value: "0", period: { number: homeLine.period?.number } };

        const periodNumber = homeLine.period?.number;
        const homePts = parseInt(homeLine.value, 10) || 0;
        const awayPts = parseInt(awayLine.value, 10) || 0;
        const scoreString = `${homePts}-${awayPts}`;
        const key = periodKey(periodNumber);
        quartersObj[key] = scoreString;
      }

      // 4) Upsert the game (eventid included)
      console.log(
        `🔵 [DEBUG] Upserting game ${awayComp.team.displayName} @ ${homeComp.team.displayName}`
      );
      const gamePayload = {
        eventid: espnEventId,
        date: isoDateOnly,
        homeTeamId,
        awayTeamId,
        homeScore: parseInt(homeComp.score, 10) || null,
        awayScore: parseInt(awayComp.score, 10) || null,
        venue: event.competitions[0].venue?.fullName || null,
        broadcast: broadcastStr,
        quarters: quartersObj,
        status: event.status?.type?.description || null,
        seasonText: `${event.season.year}${
          event.season.type.id === 3 ? "-post" : "-reg"
        }`,
      };

      const gameID = await upsertGame(client, leagueSlug, gamePayload);
      console.log(`🔵 [DEBUG] Game upserted with ID: ${gameID}`);

      // 5) Fetch the boxscore/summary for player stats
      const boxscoreUrl = `https://site.api.espn.com/apis/site/v2/sports/${getSportPath(
        leagueSlug
      )}/${leagueSlug}/summary?event=${espnEventId}`;
      console.log(`🔵 [DEBUG] Fetching boxscore from: ${boxscoreUrl}`);

      let statsRes;
      try {
        statsRes = await axios.get(boxscoreUrl);
        console.log(`🔵 [DEBUG] Successfully fetched boxscore for ${espnEventId}`);
      } catch (err) {
        console.warn(`⚠️ [DEBUG] Could not fetch stats for ${espnEventId}: ${err.message}`);
        await client.query("COMMIT");
        console.log(`🔵 [DEBUG] Committed transaction (no stats) for ${espnEventId}`);
        continue;
      }

      const playerGroups = statsRes.data.boxscore?.players || [];
      console.log(`🔵 [DEBUG] Found ${playerGroups.length} player groups in boxscore`);

      if (!playerGroups.length) {
        console.warn(`⚠️ [DEBUG] No playerGroups for game ${espnEventId}.`);
      }

      // 6) Process each player group → upsert players + stats
      for (const [groupIdx, group] of playerGroups.entries()) {
        console.log(
          `🔵 [DEBUG] Processing player group ${groupIdx + 1}/${playerGroups.length} for team ${group.team.displayName}`
        );

        const statGroup = group.statistics?.[0] || null;
        if (!statGroup) {
          console.warn(`⚠️ [DEBUG] group.statistics[0] is missing for group #${groupIdx}`);
          continue;
        }

        const espnGroupTeamId = String(group.team.id);
        let teamIdForPlayer;
        if (espnGroupTeamId === String(homeComp.team.id)) {
          teamIdForPlayer = homeTeamId;
          console.log(`🔵 [DEBUG] Group ${groupIdx} is HOME team`);
        } else if (espnGroupTeamId === String(awayComp.team.id)) {
          teamIdForPlayer = awayTeamId;
          console.log(`🔵 [DEBUG] Group ${groupIdx} is AWAY team`);
        } else {
          console.warn(
            `⚠️ [DEBUG] group.team.id "${espnGroupTeamId}" didn't match home (${homeComp.team.id}) or away (${awayComp.team.id}).`
          );
          continue;
        }

        console.log(`🔵 [DEBUG] Processing ${statGroup.athletes?.length || 0} athletes`);
        for (const athleteEntry of statGroup.athletes || []) {
          const athleteName = athleteEntry.athlete?.displayName || "Unknown";
          console.log(`🔵 [DEBUG] Processing athlete: ${athleteName}`);

          if (athleteEntry.didNotPlay) {
            console.log(`  • ${athleteName} DNP – ${athleteEntry.reason}`);
            continue;
          }

          const espnId = athleteEntry.athlete?.id;
          if (!espnId) {
            console.warn(`⚠️ [DEBUG] Skipping athlete with no ID:`, athleteEntry);
            continue;
          }
          console.log(`🔵 [DEBUG] Athlete ESPN ID: ${espnId}`);

          // Fetch detailed athlete info (can be slow—consider caching if needed)
          let detailedAthlete = {};
          try {
            console.log(`🔵 [DEBUG] Fetching details for athlete ${espnId}`);
            const playerDetails = await fetchPlayerDetails(espnId, leagueSlug);
            detailedAthlete = playerDetails?.athlete || {};
            console.log(`🔵 [DEBUG] Retrieved details for ${espnId}`);
          } catch (err) {
            console.warn(
              `⚠️ [DEBUG] Could not fetch details for athlete ${espnId}: ${err.message}`
            );
          }

          const fallbackName = athleteEntry.athlete.displayName || "Unknown";
          const playerObj = {
            id: detailedAthlete.id || espnId,
            name: detailedAthlete.displayName || fallbackName,
            position:
              detailedAthlete.position?.abbreviation ||
              athleteEntry.athlete.position?.abbreviation ||
              null,
            height: detailedAthlete.displayHeight || null,
            weight: detailedAthlete.displayWeight || null,
            birthdate: detailedAthlete.displayDOB || null,
            image: detailedAthlete.headshot?.href || null,
            draftInfo: detailedAthlete.displayDraft || null,
            jerseyNum: detailedAthlete.jersey || athleteEntry.athlete.jersey || null,
            birthplace: detailedAthlete.displayBirthPlace || null,
            age: detailedAthlete.age || null,
          };

          console.log(`🔵 [DEBUG] Upserting player: ${playerObj.name}`);
          // Assume upsertPlayer returns the newly‐upserted player’s PK
          const playerId = await upsertPlayer(client, playerObj, teamIdForPlayer, leagueSlug);
          console.log(`🔵 [DEBUG] Player upserted with ID: ${playerId}`);

          const rawStatsObj = { gameid: gameID };
          const stats = athleteEntry.stats || [];
          const statNames = statGroup.names || [];

          console.log(`🔵 [DEBUG] Processing ${stats.length} stats for ${playerObj.name}`);
          for (let i = 0; i < Math.min(stats.length, statNames.length); i++) {
            const label = statNames[i]?.trim();
            const value = stats[i];
            if (!label) continue;
            rawStatsObj[label] = value === "" ? null : value;
          }

          console.log(`🔵 [DEBUG] Raw stats before mapping:`, JSON.stringify(rawStatsObj));
          const mappedStats = mapStatsToSchema(rawStatsObj, leagueSlug);
          console.log(`🔵 [DEBUG] Mapped stats:`, JSON.stringify(mappedStats));

          console.log(`🔵 [DEBUG] Upserting stats for player ${playerId}`);
          await upsertStat(client, gameID, playerId, mappedStats);
          console.log(`🔵 [DEBUG] Stats upserted for player ${playerId}`);
        }
      }

      await client.query("COMMIT");
      console.log(`🔵 [DEBUG] Transaction committed for event ${espnEventId}`);
    } catch (err) {
      console.error(`🔴 [DEBUG] Error in transaction for event ${espnEventId}:`, err);
      try {
        await client.query("ROLLBACK");
        console.error(`🔴 [DEBUG] Transaction rolled back for ${leagueSlug} game ${espnEventId}`);
      } catch (rollbackErr) {
        console.error(`🔴 [DEBUG] Rollback failed for ${espnEventId}:`, rollbackErr);
      }
    } finally {
      client.release();
      console.log(`🔵 [DEBUG] Released database client for event ${espnEventId}`);
    }
  }
}

// ----------------------------------------------------------------------------
// 7) runWithConcurrency: unchanged
// ----------------------------------------------------------------------------

async function runWithConcurrency(tasks, limit = 5) {
  console.log(`🔵 [DEBUG] Running ${tasks.length} tasks with concurrency limit ${limit}`);
  const results = [];
  const executing = [];

  for (const [i, task] of tasks.entries()) {
    if (executing.length >= limit) {
      console.log(`🔵 [DEBUG] At concurrency limit (${limit}), waiting...`);
      await Promise.race(executing);
    }

    console.log(`🔵 [DEBUG] Starting task ${i + 1}/${tasks.length}`);
    const p = task().catch((e) => {
      console.warn(`⚠️ [DEBUG] Task ${i + 1} failed:`, e.message);
      return null;
    });
    results.push(p);

    const e = p.then(() => {
      const idx = executing.indexOf(e);
      if (idx !== -1) executing.splice(idx, 1);
      console.log(`🔵 [DEBUG] Task ${i + 1} completed`);
    });
    executing.push(e);
  }

  console.log(`🔵 [DEBUG] Waiting for all tasks to complete`);
  return Promise.all(results);
}

// ----------------------------------------------------------------------------
// 8) Main execution: iterate through leagues + dates
// ----------------------------------------------------------------------------

(async () => {
  console.log("🔵 [DEBUG] Starting main execution");
  const leagues = [
    { slug: "nba", seasonStart: "2024-10-22", seasonEnd: "2025-05-31" },
    { slug: "nfl", seasonStart: "2024-09-03", seasonEnd: "2024-12-31" },
    { slug: "nhl", seasonStart: "2024-10-01", seasonEnd: "2025-05-31" },
  ];

  try {
    for (const { slug, seasonStart, seasonEnd } of leagues) {
      console.log(`\n🔵 [DEBUG] Processing league: ${slug}`);
      const dates = getAllDatesInRange(seasonStart, seasonEnd);
      const tasks = dates.map((date, i) => async () => {
        console.log(`🔵 [DEBUG] Starting task ${i + 1}/${dates.length} for date ${date}`);
        await populateDateForLeague(date, slug);
        console.log(`🔵 [DEBUG] Completed task for date ${date}`);
      });

      console.log(`\n▶ [DEBUG] Starting ${slug.toUpperCase()} with ${tasks.length} dates...`);
      await runWithConcurrency(tasks, 5);
      console.log(`✅ [DEBUG] Finished ${slug.toUpperCase()}`);
    }
  } catch (err) {
    console.error("❌ [DEBUG] Fatal error during league import:", err);
  } finally {
    console.log("🔵 [DEBUG] Closing database pool");
    await pool.end();
    console.log("🔵 [DEBUG] Database pool closed");
    process.exit(0);
  }
})();